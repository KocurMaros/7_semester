/*
 * template_poloha_types.h
 *
 * Real-Time Workshop code generation for Simulink model "template_poloha.mdl".
 *
 * Model Version              : 1.46
 * Real-Time Workshop version : 7.0  (R2007b)  02-Aug-2007
 * C source code generated on : Sun Jan 01 02:45:50 2006
 */
#ifndef RTW_HEADER_template_poloha_types_h_
#define RTW_HEADER_template_poloha_types_h_

/* Parameters (auto storage) */
typedef struct Parameters_template_poloha Parameters_template_poloha;

/* Forward declaration for rtModel */
typedef struct RT_MODEL_template_poloha RT_MODEL_template_poloha;

#endif                                 /* RTW_HEADER_template_poloha_types_h_ */

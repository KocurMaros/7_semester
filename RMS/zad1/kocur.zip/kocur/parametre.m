clc;
clear;
%% vytvoril lubos.chovanec@stuba.sk

%% tabulkove parametre - NEMENIT
%ACS 800
Tvz = 4e-3; % pozor zmena na 4ms
Tgm = 15e-3;
J = 0.005;
B = 0.0027;
Mmax = 5;
Mn = 6.48;
N = 2500;       % IRC

%% volitelne parametre

% doba simulacie 
Tsim=5; %2[s] pre STEP signal alebo 5[s] pre Signal Builder
%% ziadana poloha
poloha1=pi;
poloha2=pi*2;
%% Vase vypocty parametrov regulatorov

% ano, ano, tu si mozes pisat vypocty

Kp=2.1675
Ki=0.4674
Kv=0.0684

%% vykreslenie grafov

% plot (data(:,1),data(:,2)); grid on;  % zelana  poloha
% plot (data(:,1),data(:,3)); grid on;  % poloha z IRC
% plot (data(:,1),data(:,4)); grid on;  % rychlost z IRC

% plot (data(:,1),data(:,5)); grid on; % zelany moment motora
% plot (data(:,1),data(:,6)); grid on; % moment motora
% plot (data(:,1),data(:,7)); grid on; % prud merany

% plot (data(:,1),data(:,6)); grid on; % regulacna odchylka polohy


